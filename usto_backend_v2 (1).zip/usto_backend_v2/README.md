# USTO Marketplace API — v0.2

Node.js + Express + PostgreSQL (Prisma). Backend for the USTO marketplace (Tajikistan).

## Web UI

After `npm run dev`, open **http://localhost:4000** in a browser. The UI lives in `public/` (plain HTML/JS, no build step) and is served by the API itself, so there is no CORS setup. It has Tajik and Russian, works on phones, and covers: register/login, catalog + search, cart and checkout, my orders (cancel while `PLACED`), seller panel (add/edit/archive products, sales), moderation queue and order status for MANAGER, and overview + user management for ADMIN. Sign in as the admin from your `.env` to create manager accounts.

## Accounts and roles

| Role | How it is created | Can do |
|---|---|---|
| BUYER | public `POST /api/auth/register` | browse, order, cancel own order while `PLACED` |
| SELLER | public register with `"role":"SELLER"` | everything a buyer can (except buy own products) + create/edit/archive own products, see own sales |
| MANAGER | **only** by an ADMIN (`POST /api/admin/users`) | moderate products, manage order status |
| COURIER | **only** by an ADMIN | sees only orders assigned to them (address, phone), marks them shipped / delivered |
| ADMIN | seed script, or by another ADMIN | everything, plus user management |

Security properties: bcrypt (cost 12); JWT carries only user id + token version, and the **role is re-read from the database on every request**, so deactivating or demoting a user, or changing a password, takes effect at once. Tokens are rejected after `change-password` / `logout-all`. Login is rate-limited per IP+email, registration per IP. `imageUrl` must be `https://`.

## What changed from v0.1

Fixed: overselling race (atomic stock guard), duplicate order lines bypassing stock checks, float money maths (Decimal), 500 on unknown ids (now 404), unrestricted order/product state changes (state machine; cancel restocks), stale-role tokens, `javascript:` image URLs, weak login throttling, login timing leak, sample admin password accepted by the seed, DB exposed on all interfaces, bcrypt 72-**byte** truncation for Cyrillic passwords, phone normalisation (`+992…`).
Added: seller edit/archive/orders, moderation queue + review note, user admin API, change password, log out everywhere, order detail and buyer cancel, pagination, `trust proxy` setting.

**Schema changed** (`User.tokenVersion`, `Product.reviewNote`, `Role.COURIER`, `Order.courierId`): run `npm run db:migrate` again.

## Setup

Node.js 20+, Docker (or PostgreSQL 16), npm.

1. `cp .env.example .env`, then set `POSTGRES_PASSWORD`, the same password inside `DATABASE_URL`, a random `JWT_SECRET`, and a unique `ADMIN_PASSWORD` (the seed refuses sample passwords).
2. `docker compose up -d db`
3. `npm install && npm run db:generate && npm run db:migrate && npm run db:seed && npm run dev`
4. `GET http://localhost:4000/api/health`
5. `npm test` (unit tests for the business rules; no database needed)

Behind nginx/a load balancer set `TRUST_PROXY=1`, or rate limiting will see one IP for everybody.

## API

Send `Authorization: Bearer <token>`.

| Method | Endpoint | Access |
|---|---|---|
| GET | `/api/health` | public |
| POST | `/api/auth/register` | public (BUYER/SELLER) |
| POST | `/api/auth/login` | public |
| GET / PATCH | `/api/auth/me` | signed-in (name, phone) |
| POST | `/api/auth/change-password` | signed-in; returns a new token |
| POST | `/api/auth/logout-all` | signed-in |
| GET | `/api/products` (`q`, `city`, `category`, `limit`, `offset`) | public, approved only |
| GET | `/api/products/:id` | public |
| POST | `/api/products` | SELLER, ADMIN |
| PATCH | `/api/products/:id` | owner, ADMIN. Changing text/category/city/image sends it back to review; price/stock do not |
| DELETE | `/api/products/:id` | owner, ADMIN (archives) |
| GET | `/api/seller/products`, `/api/seller/orders` | SELLER, ADMIN |
| GET | `/api/manager/products/pending` | MANAGER, ADMIN |
| PATCH | `/api/products/:id/review` `{decision, note?}` | MANAGER, ADMIN (PENDING only) |
| POST | `/api/orders` | BUYER, SELLER |
| GET | `/api/orders/mine`, `/api/orders/:id` | signed-in (own) / staff (any) |
| POST | `/api/orders/:id/cancel` | owner, while `PLACED` |
| GET | `/api/manager/orders` (`status`) | MANAGER, ADMIN |
| PATCH | `/api/manager/orders/:id/status` | MANAGER, ADMIN |
| GET | `/api/manager/couriers` | MANAGER, ADMIN |
| PATCH | `/api/manager/orders/:id/courier` `{courierId}` | MANAGER, ADMIN (before shipping) |
| GET | `/api/courier/orders` | COURIER (own orders only) |
| PATCH | `/api/courier/orders/:id/status` `{SHIPPED\|DELIVERED}` | COURIER (own orders only) |
| GET | `/api/admin/overview`, `/api/admin/users` | ADMIN |
| POST | `/api/admin/users` | ADMIN (create staff) |
| PATCH | `/api/admin/users/:id` `{role?, active?}` | ADMIN (not on yourself) |

Order flow: `PLACED → CONFIRMED → PROCESSING → SHIPPED → DELIVERED`. A manager or admin assigns a courier; an order cannot become `SHIPPED` without one, and the courier then marks it shipped and delivered; cancel is possible until `SHIPPED` and returns stock.

## Still not production-ready

- No SMS/OTP login (email + password only): needs a provider for Tajikistan.
- No payment gateway (cash on delivery or manual payment only) and no courier integration.
- No image upload (HTTPS URL only), no email verification or password reset by email, no refresh tokens.
- No audit log and no integration tests against a real database. Only the pure business rules are unit-tested.
- The old prototype `usto_marketplace_v1.html` is not connected to this API; the built-in UI in `public/` replaces it. The UI was tested in a browser against a mock of the API, not against a live database.
- Before launch: HTTPS, secrets management, DB backups, monitoring, privacy policy/terms, security review.
