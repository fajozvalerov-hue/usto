import "dotenv/config";
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { KNOWN_WEAK_PASSWORDS, passwordFitsBcrypt } from "../src/rules.js";

const prisma = new PrismaClient();
try {
  const email = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || "";
  if (!email || password.length < 12) {
    console.log("Skipping admin bootstrap: set ADMIN_EMAIL and ADMIN_PASSWORD (12+ chars) in .env.");
  } else if (KNOWN_WEAK_PASSWORDS.has(password) || !passwordFitsBcrypt(password)) {
    console.error("Refusing to create admin: ADMIN_PASSWORD is a sample value or longer than 72 bytes. Choose a unique password.");
    process.exitCode = 1;
  } else {
    const existing = await prisma.user.findUnique({ where: { email } });
    if (!existing) {
      await prisma.user.create({
        data: {
          name: process.env.ADMIN_NAME || "USTO Admin",
          email,
          passwordHash: await bcrypt.hash(password, 12),
          role: "ADMIN"
        }
      });
      console.log(`Created initial admin: ${email}`);
    } else {
      console.log("Admin account already exists; no role or password was changed.");
    }
  }
} finally {
  await prisma.$disconnect();
}
