// Pure business rules: no database, no framework. Unit-tested in test/rules.test.js.

// Order status machine. Terminal states have no outgoing transitions.
export const ORDER_TRANSITIONS = {
  PLACED: ["CONFIRMED", "CANCELLED"],
  CONFIRMED: ["PROCESSING", "CANCELLED"],
  PROCESSING: ["SHIPPED", "CANCELLED"],
  SHIPPED: ["DELIVERED"],
  DELIVERED: [],
  CANCELLED: []
};

export const canTransitionOrder = (from, to) => (ORDER_TRANSITIONS[from] || []).includes(to);

// Stock is returned only when an order is cancelled (it was decremented at placement).
export const restocksOnCancel = to => to === "CANCELLED";

// Couriers may only move their own orders forward through the delivery steps.
export const COURIER_TARGETS = ["SHIPPED", "DELIVERED"];
// An order cannot leave the warehouse without a named courier.
export const requiresCourier = to => to === "SHIPPED";
export const ROLES = ["BUYER", "SELLER", "MANAGER", "ADMIN", "COURIER"];

// Product moderation: only PENDING products can be approved or rejected.
export const canReviewProduct = status => status === "PENDING";

// Merge duplicate product lines so stock checks see the real total per product.
export function mergeItems(items) {
  const map = new Map();
  for (const { productId, quantity } of items) {
    map.set(productId, (map.get(productId) || 0) + quantity);
  }
  // Sorted by id: every transaction locks rows in the same order, which avoids deadlocks.
  return [...map.entries()]
    .map(([productId, quantity]) => ({ productId, quantity }))
    .sort((a, b) => (a.productId < b.productId ? -1 : a.productId > b.productId ? 1 : 0));
}

// Normalise phone numbers. 9 local digits (Tajikistan) or 992XXXXXXXXX become +992XXXXXXXXX.
// Returns null when the value is not a plausible phone number.
export function normalizePhone(raw) {
  const cleaned = String(raw ?? "").replace(/[\s\-().]/g, "");
  if (/^\d{9}$/.test(cleaned)) return `+992${cleaned}`;
  if (/^992\d{9}$/.test(cleaned)) return `+${cleaned}`;
  if (/^00\d{9,15}$/.test(cleaned)) return `+${cleaned.slice(2)}`;
  if (/^\+\d{9,15}$/.test(cleaned)) return cleaned;
  return null;
}

// bcrypt only uses the first 72 BYTES. Cyrillic/Tajik letters take 2 bytes each.
export const passwordFitsBcrypt = pw => Buffer.byteLength(pw, "utf8") <= 72;

export const KNOWN_WEAK_PASSWORDS = new Set([
  "ChangeMe_Immediately_123!",
  "change_this_password"
]);
