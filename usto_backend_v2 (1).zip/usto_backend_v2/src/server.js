import "dotenv/config";
import { prisma } from "./prisma.js";
import { createApp } from "./app.js";

for (const key of ["DATABASE_URL", "JWT_SECRET"]) {
  if (!process.env[key]) throw new Error(`Missing required environment variable: ${key}`);
}
if (process.env.JWT_SECRET.length < 32) throw new Error("JWT_SECRET must be at least 32 characters");
if (process.env.NODE_ENV === "production" && /replace-with|change/i.test(process.env.JWT_SECRET)) {
  throw new Error("JWT_SECRET looks like the sample value");
}

const port = Number(process.env.PORT || 4000);
const server = createApp().listen(port, () => console.log(`USTO API listening on http://localhost:${port}`));

async function shutdown() {
  server.close(async () => { await prisma.$disconnect(); process.exit(0); });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
