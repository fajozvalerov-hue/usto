import express from "express";
import { fileURLToPath } from "node:url";
import cors from "cors";
import helmet from "helmet";
import rateLimit, { ipKeyGenerator } from "express-rate-limit";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "./prisma.js";
import { signToken, requireAuth, allowRoles } from "./security.js";
import {
  ORDER_TRANSITIONS, COURIER_TARGETS, requiresCourier, ROLES, canTransitionOrder, canReviewProduct, restocksOnCancel, mergeItems, normalizePhone, passwordFitsBcrypt
} from "./rules.js";

class HttpError extends Error {
  constructor(status, code, extra = {}) { super(code); this.status = status; this.code = code; this.extra = extra; }
}

// ---------- validation schemas ----------
const phoneSchema = z.string().trim()
  .transform(v => normalizePhone(v))
  .refine(v => v !== null, { message: "INVALID_PHONE" });
const passwordSchema = z.string().min(10).max(128)
  .refine(passwordFitsBcrypt, { message: "PASSWORD_TOO_LONG (max 72 bytes; Cyrillic letters use 2 bytes each)" });
const emailSchema = z.email().max(254).transform(v => v.toLowerCase());
const httpsUrl = z.string().max(1000).url().refine(v => /^https:\/\//i.test(v), { message: "imageUrl must start with https://" });

const registerSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: emailSchema,
  phone: phoneSchema.optional(),
  password: passwordSchema,
  // Public registration may never create privileged staff accounts.
  role: z.enum(["BUYER", "SELLER"]).default("BUYER")
});
const loginSchema = z.object({ email: emailSchema, password: z.string().min(1).max(256) });
const productFields = {
  titleTg: z.string().trim().min(2).max(140),
  titleRu: z.string().trim().min(2).max(140),
  descriptionTg: z.string().max(3000),
  descriptionRu: z.string().max(3000),
  category: z.string().trim().min(2).max(80),
  priceTjs: z.coerce.number().positive().max(100000000),
  stock: z.coerce.number().int().min(0).max(100000),
  city: z.string().trim().min(2).max(80),
  imageUrl: httpsUrl
};
const productSchema = z.object({
  ...productFields,
  descriptionTg: productFields.descriptionTg.optional(),
  descriptionRu: productFields.descriptionRu.optional(),
  imageUrl: productFields.imageUrl.optional()
});
const productPatchSchema = z.object(productFields).partial().refine(o => Object.keys(o).length > 0, { message: "EMPTY_UPDATE" });
// Changing these needs a new moderation pass; price and stock do not.
const MODERATED_FIELDS = ["titleTg", "titleRu", "descriptionTg", "descriptionRu", "category", "city", "imageUrl"];

const orderSchema = z.object({
  city: z.string().trim().min(2).max(80),
  address: z.string().trim().min(5).max(300),
  phone: phoneSchema,
  note: z.string().max(1000).optional(),
  items: z.array(z.object({
    productId: z.string().min(5).max(64),
    quantity: z.coerce.number().int().min(1).max(100)
  })).min(1).max(30)
});

// ---------- helpers ----------
const safeUser = ({ passwordHash, tokenVersion, ...user }) => user;
const publicProduct = ({ approvedBy, reviewNote, ...p }) => p;
const str = v => (typeof v === "string" && v.trim() ? v.trim() : undefined);
const clampLimit = (v, def, max) => Math.min(Math.max(Number(v) || def, 1), max);
const validate = (schema, data) => {
  const r = schema.safeParse(data);
  if (!r.success) throw new HttpError(400, "VALIDATION_ERROR", { details: r.error.issues });
  return r.data;
};

// Constant-time-ish login: always run bcrypt, even for unknown emails.
const DUMMY_HASH = bcrypt.hashSync("usto-timing-equaliser", 12);

// Move an order to a new status atomically, restocking on cancel.
// `ownerId` restricts the order to one buyer; `onlyFrom` demands a specific current status
// (buyers may cancel only while the order is still PLACED).
async function transitionOrder(orderId, to, { ownerId, onlyFrom, courierId } = {}) {
  return prisma.$transaction(async tx => {
    const order = await tx.order.findUnique({ where: { id: orderId }, include: { items: true } });
    if (!order || (ownerId && order.buyerId !== ownerId) || (courierId && order.courierId !== courierId)) throw new HttpError(404, "NOT_FOUND");
    if ((onlyFrom && order.status !== onlyFrom) || !canTransitionOrder(order.status, to)) {
      throw new HttpError(409, "INVALID_STATUS_TRANSITION", { from: order.status, to });
    }
    if (requiresCourier(to) && !order.courierId) throw new HttpError(409, "COURIER_REQUIRED");
    // Compare-and-set on the old status: two concurrent changes cannot both win (no double restock).
    const { count } = await tx.order.updateMany({ where: { id: orderId, status: order.status }, data: { status: to } });
    if (count !== 1) throw new HttpError(409, "ORDER_CHANGED_CONCURRENTLY");
    if (restocksOnCancel(to)) {
      for (const item of [...order.items].sort((a, b) => (a.productId < b.productId ? -1 : 1))) {
        await tx.product.update({ where: { id: item.productId }, data: { stock: { increment: item.quantity } } });
      }
    }
    return tx.order.findUnique({ where: { id: orderId }, include: { items: true } });
  });
}

export function createApp() {
  const app = express();
  app.disable("x-powered-by");
  const hops = Number(process.env.TRUST_PROXY || 0);
  if (hops > 0) app.set("trust proxy", hops);

  // Product images come from seller-supplied https URLs, so allow https images in the CSP.
  // Scripts stay 'self' only (the web UI in /public uses no inline scripts).
  app.use(helmet({ contentSecurityPolicy: { directives: { "img-src": ["'self'", "data:", "https:"] } } }));
  app.use(cors({
    origin: (process.env.CORS_ORIGIN || "http://localhost:5173").split(",").map(x => x.trim()),
    credentials: false
  }));
  app.use(express.json({ limit: "1mb" }));
  app.use("/api", rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: "draft-8", legacyHeaders: false }));

  // Stricter limits on credential endpoints. Login is keyed on IP + email so one attacker
  // cannot lock out everybody, and one account cannot be hammered from a single address.
  const loginLimiter = rateLimit({
    windowMs: 15 * 60_000, limit: 10, skipSuccessfulRequests: true,
    standardHeaders: "draft-8", legacyHeaders: false,
    keyGenerator: req => `${ipKeyGenerator(req.ip)}|${String(req.body?.email || "").toLowerCase().slice(0, 254)}`,
    handler: (_req, res) => res.status(429).json({ error: "TOO_MANY_ATTEMPTS" })
  });
  const registerLimiter = rateLimit({
    windowMs: 60 * 60_000, limit: 20, standardHeaders: "draft-8", legacyHeaders: false,
    keyGenerator: req => ipKeyGenerator(req.ip),
    handler: (_req, res) => res.status(429).json({ error: "TOO_MANY_ATTEMPTS" })
  });

  const asSeller = [requireAuth, allowRoles("SELLER", "ADMIN")];
  const asStaff = [requireAuth, allowRoles("MANAGER", "ADMIN")];
  const asAdmin = [requireAuth, allowRoles("ADMIN")];

  // Built-in web UI (same origin as the API, so no CORS needed).
  app.use(express.static(fileURLToPath(new URL("../public", import.meta.url))));

  app.get("/api/health", (_req, res) => res.json({ ok: true, service: "usto-api", version: "0.2.0" }));

  // ================= accounts =================
  app.post("/api/auth/register", registerLimiter, async (req, res) => {
    const { name, email, phone, password, role } = validate(registerSchema, req.body);
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({ data: { name, email, phone, passwordHash, role } });
    res.status(201).json({ user: safeUser(user), token: signToken(user) });
  });

  app.post("/api/auth/login", loginLimiter, async (req, res) => {
    const { email, password } = validate(loginSchema, req.body);
    const user = await prisma.user.findUnique({ where: { email } });
    const ok = await bcrypt.compare(password, user?.passwordHash ?? DUMMY_HASH);
    if (!user || !user.active || !ok) return res.status(401).json({ error: "INVALID_CREDENTIALS" });
    res.json({ user: safeUser(user), token: signToken(user) });
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    const user = await prisma.user.findUnique({ where: { id: req.auth.userId } });
    res.json({ user: safeUser(user) });
  });

  app.patch("/api/auth/me", requireAuth, async (req, res) => {
    const data = validate(z.object({ name: z.string().trim().min(2).max(80), phone: phoneSchema }).partial()
      .refine(o => Object.keys(o).length > 0, { message: "EMPTY_UPDATE" }), req.body);
    const user = await prisma.user.update({ where: { id: req.auth.userId }, data });
    res.json({ user: safeUser(user) });
  });

  app.post("/api/auth/change-password", requireAuth, loginLimiter, async (req, res) => {
    const { currentPassword, newPassword } = validate(
      z.object({ currentPassword: z.string().min(1).max(256), newPassword: passwordSchema }), req.body);
    const me = await prisma.user.findUnique({ where: { id: req.auth.userId } });
    if (!(await bcrypt.compare(currentPassword, me.passwordHash))) return res.status(401).json({ error: "INVALID_CREDENTIALS" });
    // tokenVersion bump invalidates every previously issued token; a fresh one is returned.
    const user = await prisma.user.update({
      where: { id: me.id },
      data: { passwordHash: await bcrypt.hash(newPassword, 12), tokenVersion: { increment: 1 } }
    });
    res.json({ user: safeUser(user), token: signToken(user) });
  });

  app.post("/api/auth/logout-all", requireAuth, async (req, res) => {
    await prisma.user.update({ where: { id: req.auth.userId }, data: { tokenVersion: { increment: 1 } } });
    res.status(204).end();
  });

  // ================= catalog (public) =================
  app.get("/api/products", async (req, res) => {
    const where = { status: "APPROVED" };
    const category = str(req.query.category), city = str(req.query.city), q = str(req.query.q);
    if (category) where.category = category;
    if (city) where.city = city;
    if (q) where.OR = [
      { titleTg: { contains: q.slice(0, 100), mode: "insensitive" } },
      { titleRu: { contains: q.slice(0, 100), mode: "insensitive" } }
    ];
    const skip = Math.max(Number(req.query.offset) || 0, 0);
    const products = await prisma.product.findMany({
      where, orderBy: { createdAt: "desc" }, take: clampLimit(req.query.limit, 40, 100), skip
    });
    res.json({ products: products.map(publicProduct) });
  });

  app.get("/api/products/:id", async (req, res) => {
    const p = await prisma.product.findFirst({ where: { id: req.params.id, status: "APPROVED" } });
    if (!p) throw new HttpError(404, "NOT_FOUND");
    res.json({ product: publicProduct(p) });
  });

  // ================= seller =================
  app.post("/api/products", ...asSeller, async (req, res) => {
    const data = validate(productSchema, req.body);
    const product = await prisma.product.create({ data: { ...data, status: "PENDING", sellerId: req.auth.userId } });
    res.status(201).json({ product });
  });

  app.get("/api/seller/products", ...asSeller, async (req, res) => {
    const products = await prisma.product.findMany({
      where: req.auth.role === "ADMIN" ? {} : { sellerId: req.auth.userId },
      orderBy: { createdAt: "desc" }, take: clampLimit(req.query.limit, 100, 200), skip: Math.max(Number(req.query.offset) || 0, 0)
    });
    res.json({ products });
  });

  const ownProduct = async req => {
    const p = await prisma.product.findUnique({ where: { id: req.params.id } });
    // 404 (not 403) so sellers cannot probe other sellers' product ids.
    if (!p || (req.auth.role !== "ADMIN" && p.sellerId !== req.auth.userId)) throw new HttpError(404, "NOT_FOUND");
    return p;
  };

  app.patch("/api/products/:id", ...asSeller, async (req, res) => {
    const current = await ownProduct(req);
    if (current.status === "ARCHIVED") throw new HttpError(409, "PRODUCT_ARCHIVED");
    const data = validate(productPatchSchema, req.body);
    const needsReview = MODERATED_FIELDS.some(f => f in data && data[f] !== current[f]);
    const product = await prisma.product.update({
      where: { id: current.id },
      data: { ...data, ...(needsReview ? { status: "PENDING", approvedBy: null, reviewNote: null } : {}) }
    });
    res.json({ product, resubmittedForReview: needsReview });
  });

  // Soft delete: order history keeps pointing at the product.
  app.delete("/api/products/:id", ...asSeller, async (req, res) => {
    const current = await ownProduct(req);
    const product = await prisma.product.update({ where: { id: current.id }, data: { status: "ARCHIVED" } });
    res.json({ product });
  });

  // Orders that contain this seller's products. No buyer contact data: delivery is run by the platform.
  app.get("/api/seller/orders", ...asSeller, async (req, res) => {
    const items = await prisma.orderItem.findMany({
      where: req.auth.role === "ADMIN" ? {} : { product: { sellerId: req.auth.userId } },
      include: { order: { select: { id: true, status: true, city: true, createdAt: true } } },
      orderBy: { order: { createdAt: "desc" } }, take: clampLimit(req.query.limit, 100, 200)
    });
    res.json({ items });
  });

  // ================= moderation =================
  app.get("/api/manager/products/pending", ...asStaff, async (_req, res) => {
    const products = await prisma.product.findMany({
      where: { status: "PENDING" }, orderBy: { createdAt: "asc" }, take: 100,
      include: { seller: { select: { id: true, name: true } } }
    });
    res.json({ products });
  });

  app.patch("/api/products/:id/review", ...asStaff, async (req, res) => {
    const { decision, note } = validate(
      z.object({ decision: z.enum(["APPROVED", "REJECTED"]), note: z.string().trim().max(500).optional() }), req.body);
    const current = await prisma.product.findUnique({ where: { id: req.params.id } });
    if (!current) throw new HttpError(404, "NOT_FOUND");
    if (!canReviewProduct(current.status)) throw new HttpError(409, "INVALID_STATE", { status: current.status });
    const { count } = await prisma.product.updateMany({
      where: { id: current.id, status: "PENDING" },
      data: { status: decision, approvedBy: req.auth.userId, reviewNote: note ?? null }
    });
    if (count !== 1) throw new HttpError(409, "INVALID_STATE");
    res.json({ product: await prisma.product.findUnique({ where: { id: current.id } }) });
  });

  // ================= orders =================
  app.post("/api/orders", requireAuth, allowRoles("BUYER", "SELLER"), async (req, res) => {
    const v = validate(orderSchema, req.body);
    const lines = mergeItems(v.items); // duplicates summed, sorted for consistent lock order

    const order = await prisma.$transaction(async tx => {
      const products = await tx.product.findMany({
        where: { id: { in: lines.map(l => l.productId) }, status: "APPROVED" }
      });
      if (products.length !== lines.length) throw new HttpError(400, "PRODUCT_UNAVAILABLE");
      const byId = new Map(products.map(p => [p.id, p]));
      if (products.some(p => p.sellerId === req.auth.userId)) throw new HttpError(400, "CANNOT_BUY_OWN_PRODUCT");

      let total = new Prisma.Decimal(0);
      for (const line of lines) {
        // Atomic guard: the decrement only happens if enough stock is still there at this instant.
        const { count } = await tx.product.updateMany({
          where: { id: line.productId, status: "APPROVED", stock: { gte: line.quantity } },
          data: { stock: { decrement: line.quantity } }
        });
        if (count !== 1) throw new HttpError(409, "INSUFFICIENT_STOCK", { productId: line.productId });
        total = total.add(new Prisma.Decimal(byId.get(line.productId).priceTjs).mul(line.quantity));
      }
      return tx.order.create({
        data: {
          buyerId: req.auth.userId, city: v.city, address: v.address, phone: v.phone, note: v.note,
          totalTjs: total,
          items: { create: lines.map(line => {
            const p = byId.get(line.productId);
            return { productId: p.id, productTitleTg: p.titleTg, productTitleRu: p.titleRu, unitPriceTjs: p.priceTjs, quantity: line.quantity };
          }) }
        },
        include: { items: true }
      });
    });
    res.status(201).json({ order });
  });

  app.get("/api/orders/mine", requireAuth, async (req, res) => {
    const orders = await prisma.order.findMany({
      where: { buyerId: req.auth.userId }, include: { items: true }, orderBy: { createdAt: "desc" },
      take: clampLimit(req.query.limit, 50, 100), skip: Math.max(Number(req.query.offset) || 0, 0)
    });
    res.json({ orders });
  });

  app.get("/api/orders/:id", requireAuth, async (req, res) => {
    const order = await prisma.order.findUnique({ where: { id: req.params.id }, include: { items: true } });
    const isStaff = ["MANAGER", "ADMIN"].includes(req.auth.role);
    if (!order || (!isStaff && order.buyerId !== req.auth.userId)) throw new HttpError(404, "NOT_FOUND");
    res.json({ order });
  });

  // Buyers can cancel their own order until staff confirm it.
  app.post("/api/orders/:id/cancel", requireAuth, async (req, res) => {
    const order = await transitionOrder(req.params.id, "CANCELLED", { ownerId: req.auth.userId, onlyFrom: "PLACED" });
    res.json({ order });
  });

  app.get("/api/manager/orders", ...asStaff, async (req, res) => {
    const status = str(req.query.status);
    if (status && !(status in ORDER_TRANSITIONS)) throw new HttpError(400, "VALIDATION_ERROR", { details: "invalid status" });
    const orders = await prisma.order.findMany({
      where: status ? { status } : {},
      include: { items: true, buyer: { select: { id: true, name: true, email: true, phone: true } }, courier: { select: { id: true, name: true, phone: true } } },
      orderBy: { createdAt: "desc" }, take: clampLimit(req.query.limit, 100, 200), skip: Math.max(Number(req.query.offset) || 0, 0)
    });
    res.json({ orders });
  });

  app.patch("/api/manager/orders/:id/status", ...asStaff, async (req, res) => {
    const { status } = validate(
      z.object({ status: z.enum(["CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED"]) }), req.body);
    res.json({ order: await transitionOrder(req.params.id, status) });
  });

  // ================= couriers =================
  // Managers/admins pick which courier delivers an order.
  app.get("/api/manager/couriers", ...asStaff, async (_req, res) => {
    const couriers = await prisma.user.findMany({
      where: { role: "COURIER", active: true }, select: { id: true, name: true, phone: true }, orderBy: { name: "asc" }
    });
    res.json({ couriers });
  });

  app.patch("/api/manager/orders/:id/courier", ...asStaff, async (req, res) => {
    const { courierId } = validate(z.object({ courierId: z.string().min(5).max(64).nullable() }), req.body);
    const order = await prisma.order.findUnique({ where: { id: req.params.id } });
    if (!order) throw new HttpError(404, "NOT_FOUND");
    if (["SHIPPED", "DELIVERED", "CANCELLED"].includes(order.status)) throw new HttpError(409, "INVALID_STATE", { status: order.status });
    if (courierId) {
      const c = await prisma.user.findFirst({ where: { id: courierId, role: "COURIER", active: true } });
      if (!c) throw new HttpError(400, "COURIER_UNAVAILABLE");
    }
    const updated = await prisma.order.update({
      where: { id: order.id }, data: { courierId },
      include: { items: true, courier: { select: { id: true, name: true, phone: true } } }
    });
    res.json({ order: updated });
  });

  const asCourier = [requireAuth, allowRoles("COURIER")];
  // A courier sees only their own orders, with the address and phone needed to deliver.
  app.get("/api/courier/orders", ...asCourier, async (req, res) => {
    const orders = await prisma.order.findMany({
      where: { courierId: req.auth.userId, status: { in: ["CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED"] } },
      include: { items: true, buyer: { select: { name: true, phone: true } } },
      orderBy: { createdAt: "desc" }, take: clampLimit(req.query.limit, 100, 200)
    });
    res.json({ orders });
  });

  app.patch("/api/courier/orders/:id/status", ...asCourier, async (req, res) => {
    const { status } = validate(z.object({ status: z.enum(COURIER_TARGETS) }), req.body);
    res.json({ order: await transitionOrder(req.params.id, status, { courierId: req.auth.userId }) });
  });

  // ================= admin: users & overview =================
  app.get("/api/admin/overview", ...asAdmin, async (_req, res) => {
    const [users, products, orders, approvedProducts, pendingProducts] = await Promise.all([
      prisma.user.count(), prisma.product.count(), prisma.order.count(),
      prisma.product.count({ where: { status: "APPROVED" } }), prisma.product.count({ where: { status: "PENDING" } })
    ]);
    res.json({ users, products, approvedProducts, pendingProducts, orders });
  });

  app.get("/api/admin/users", ...asAdmin, async (req, res) => {
    const where = {};
    const role = str(req.query.role), q = str(req.query.q);
    if (role && ROLES.includes(role)) where.role = role;
    if (q) where.OR = [
      { name: { contains: q.slice(0, 100), mode: "insensitive" } },
      { email: { contains: q.slice(0, 100), mode: "insensitive" } }
    ];
    const users = await prisma.user.findMany({
      where, orderBy: { createdAt: "desc" }, take: clampLimit(req.query.limit, 50, 200), skip: Math.max(Number(req.query.offset) || 0, 0)
    });
    res.json({ users: users.map(safeUser) });
  });

  // The only way to create MANAGER/COURIER/ADMIN accounts.
  app.post("/api/admin/users", ...asAdmin, async (req, res) => {
    const d = validate(registerSchema.extend({ role: z.enum(ROLES) }), req.body);
    const user = await prisma.user.create({
      data: { name: d.name, email: d.email, phone: d.phone, role: d.role, passwordHash: await bcrypt.hash(d.password, 12) }
    });
    res.status(201).json({ user: safeUser(user) });
  });

  app.patch("/api/admin/users/:id", ...asAdmin, async (req, res) => {
    const d = validate(z.object({ role: z.enum(ROLES), active: z.boolean() }).partial()
      .refine(o => Object.keys(o).length > 0, { message: "EMPTY_UPDATE" }), req.body);
    // Prevent an admin from locking themselves (and possibly everyone) out.
    if (req.params.id === req.auth.userId) throw new HttpError(400, "CANNOT_MODIFY_SELF");
    const user = await prisma.user.update({ where: { id: req.params.id }, data: d });
    res.json({ user: safeUser(user) });
  });

  // ================= errors =================
  app.use("/api", (_req, res) => res.status(404).json({ error: "NOT_FOUND" }));

  app.use((err, _req, res, _next) => {
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.code, ...err.extra });
    if (err?.type === "entity.parse.failed") return res.status(400).json({ error: "INVALID_JSON" });
    if (err?.type === "entity.too.large") return res.status(413).json({ error: "PAYLOAD_TOO_LARGE" });
    if (err?.code === "P2025") return res.status(404).json({ error: "NOT_FOUND" });
    if (err?.code === "P2002") return res.status(409).json({ error: "EMAIL_OR_PHONE_ALREADY_EXISTS" });
    console.error(err);
    res.status(500).json({ error: "INTERNAL_SERVER_ERROR" });
  });

  return app;
}
