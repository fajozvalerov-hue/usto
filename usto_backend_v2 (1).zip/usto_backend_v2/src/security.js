import jwt from "jsonwebtoken";
import { prisma } from "./prisma.js";

const ISSUER = "usto-api";
const AUDIENCE = "usto-web";

export function signToken(user) {
  return jwt.sign(
    { sub: user.id, tv: user.tokenVersion },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "2h", issuer: ISSUER, audience: AUDIENCE, algorithm: "HS256" }
  );
}

// The role is NOT taken from the token. The account is loaded on every request, so a
// deactivated user, a demoted staff member or a changed password takes effect immediately.
export async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: "AUTH_REQUIRED" });
    let payload;
    try {
      payload = jwt.verify(token, process.env.JWT_SECRET, { issuer: ISSUER, audience: AUDIENCE, algorithms: ["HS256"] });
    } catch {
      return res.status(401).json({ error: "INVALID_OR_EXPIRED_TOKEN" });
    }
    const user = await prisma.user.findUnique({
      where: { id: payload.sub },
      select: { id: true, role: true, active: true, tokenVersion: true }
    });
    if (!user || !user.active || user.tokenVersion !== payload.tv) {
      return res.status(401).json({ error: "INVALID_OR_EXPIRED_TOKEN" });
    }
    req.auth = { userId: user.id, role: user.role };
    next();
  } catch (e) {
    next(e);
  }
}

export const allowRoles = (...roles) => (req, res, next) => {
  if (!req.auth || !roles.includes(req.auth.role)) {
    return res.status(403).json({ error: "FORBIDDEN" });
  }
  next();
};
