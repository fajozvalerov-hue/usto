"use strict";
// USTO web UI. Plain JS, no build step. All data is inserted with textContent (never innerHTML),
// so seller-supplied text cannot inject markup.

// ---------- translations ----------
const T = {
  tg: {
    catalog: "Каталог", cart: "Сабад", orders: "Фармоишҳо", seller: "Фурӯшанда", moderation: "Назорат", admin: "Админ",
    account: "Ҳисоб", login: "Даромад", register: "Сабти ном", logout: "Баромадан",
    email: "Почтаи электронӣ", password: "Парол", name: "Ном", phone: "Телефон", role: "Нақш",
    buyer: "Харидор", sellerRole: "Фурӯшанда", manager: "Менеҷер", adminRole: "Администратор",
    search: "Ҷустуҷӯ…", city: "Шаҳр", allCities: "Ҳамаи шаҳрҳо", category: "Категория", find: "Ёфтан",
    addToCart: "Ба сабад", inStock: "дар анбор", outOfStock: "тамом шуд", noProducts: "Маҳсулот ёфт нашуд",
    cartEmpty: "Сабад холӣ аст", total: "Ҷамъ", checkout: "Фармоиш додан", address: "Суроға", note: "Эзоҳ",
    remove: "Тоза", placeOrder: "Тасдиқи фармоиш", orderPlaced: "Фармоиш қабул шуд",
    noOrders: "Фармоиш нест", cancel: "Бекор кардан", save: "Захира", create: "Сохтан", archive: "Бойгонӣ",
    approve: "Тасдиқ", reject: "Рад", pending: "Интизори назорат", newProduct: "Маҳсулоти нав",
    titleTg: "Ном (тоҷикӣ)", titleRu: "Ном (русӣ)", descTg: "Тавсиф (тоҷикӣ)", descRu: "Тавсиф (русӣ)",
    price: "Нарх (сомонӣ)", stock: "Миқдор", imageUrl: "Суроғаи расм (https://…)", myProducts: "Маҳсулоти ман",
    sales: "Фурӯшҳои ман", status: "Ҳолат", reviewNote: "Эзоҳ барои фурӯшанда", users: "Корбарон",
    newUser: "Сохтани корбар", active: "Фаъол", overview: "Ҳисобот", usersN: "Корбарон", productsN: "Маҳсулот",
    approvedN: "Тасдиқшуда", pendingN: "Интизор", ordersN: "Фармоишҳо", changePw: "Иваз кардани парол",
    currentPw: "Пароли ҷорӣ", newPw: "Пароли нав", logoutAll: "Баромадан аз ҳама дастгоҳҳо", saved: "Захира шуд",
    pwHint: "Камаш 10 аломат", loginFirst: "Аввал ворид шавед", buyer_: "Харидор", qty: "Адад", currency: "сомонӣ",
    resubmitted: "Маҳсулот барои назорати нав фиристода шуд", language: "Забон", needsLogin: "Барои харидан ворид шавед",
    allStatuses: "Ҳамаи ҳолатҳо", move: "Гузариш ба…", noItems: "Холӣ", sellerNote: "Эзоҳи назоратчӣ",
    s_PLACED: "Қабул шуд", s_CONFIRMED: "Тасдиқ шуд", s_PROCESSING: "Омодагӣ", s_SHIPPED: "Фиристода шуд",
    s_DELIVERED: "Расонида шуд", s_CANCELLED: "Бекор шуд", s_PENDING: "Интизор", s_APPROVED: "Тасдиқ шуд",
    s_REJECTED: "Рад шуд", s_ARCHIVED: "Дар бойгонӣ",
    err_INVALID_CREDENTIALS: "Почта ё парол нодуруст аст", err_EMAIL_OR_PHONE_ALREADY_EXISTS: "Ин почта ё телефон аллакай сабт шудааст",
    err_TOO_MANY_ATTEMPTS: "Кӯшишҳо хеле зиёд. Баъдтар кӯшиш кунед", err_INSUFFICIENT_STOCK: "Миқдори кофӣ дар анбор нест",
    err_PRODUCT_UNAVAILABLE: "Маҳсулот дастрас нест", err_CANNOT_BUY_OWN_PRODUCT: "Маҳсулоти худро харида намешавад",
    err_VALIDATION_ERROR: "Маълумот нодуруст пур шудааст", err_FORBIDDEN: "Иҷозат нест", err_NOT_FOUND: "Ёфт нашуд",
    err_INVALID_STATUS_TRANSITION: "Ин гузариши ҳолат имконнопазир аст", err_INVALID_STATE: "Ин амал дар ҳолати ҷорӣ имконнопазир аст",
    err_CANNOT_MODIFY_SELF: "Ҳисоби худро тағйир додан мумкин нест", err_INVALID_OR_EXPIRED_TOKEN: "Сессия тамом шуд. Дубора ворид шавед",
    courier: "Курьер", courierRole: "Курьер", deliveries: "Расонидани ман", assignCourier: "Курьерро таъин кунед", noCourier: "Курьер таъин нашудааст",
    markShipped: "Гирифтам, мебарам", markDelivered: "Расонида шуд", buyerName: "Харидор", waitingManager: "Интизори омодагии менеҷер",
    err_COURIER_REQUIRED: "Аввал курьерро таъин кунед", err_COURIER_UNAVAILABLE: "Ин курьер дастрас нест",
    err_network: "Сервер ҷавоб намедиҳад"
  },
  ru: {
    catalog: "Каталог", cart: "Корзина", orders: "Заказы", seller: "Продавец", moderation: "Модерация", admin: "Админ",
    account: "Аккаунт", login: "Войти", register: "Регистрация", logout: "Выйти",
    email: "Эл. почта", password: "Пароль", name: "Имя", phone: "Телефон", role: "Роль",
    buyer: "Покупатель", sellerRole: "Продавец", manager: "Менеджер", adminRole: "Администратор",
    search: "Поиск…", city: "Город", allCities: "Все города", category: "Категория", find: "Найти",
    addToCart: "В корзину", inStock: "в наличии", outOfStock: "нет в наличии", noProducts: "Товары не найдены",
    cartEmpty: "Корзина пуста", total: "Итого", checkout: "Оформить заказ", address: "Адрес", note: "Комментарий",
    remove: "Убрать", placeOrder: "Подтвердить заказ", orderPlaced: "Заказ принят",
    noOrders: "Заказов нет", cancel: "Отменить", save: "Сохранить", create: "Создать", archive: "В архив",
    approve: "Одобрить", reject: "Отклонить", pending: "Ожидают модерации", newProduct: "Новый товар",
    titleTg: "Название (тадж.)", titleRu: "Название (рус.)", descTg: "Описание (тадж.)", descRu: "Описание (рус.)",
    price: "Цена (сомони)", stock: "Количество", imageUrl: "Ссылка на фото (https://…)", myProducts: "Мои товары",
    sales: "Мои продажи", status: "Статус", reviewNote: "Комментарий для продавца", users: "Пользователи",
    newUser: "Создать пользователя", active: "Активен", overview: "Сводка", usersN: "Пользователи", productsN: "Товары",
    approvedN: "Одобрено", pendingN: "Ожидают", ordersN: "Заказы", changePw: "Смена пароля",
    currentPw: "Текущий пароль", newPw: "Новый пароль", logoutAll: "Выйти на всех устройствах", saved: "Сохранено",
    pwHint: "Минимум 10 символов", loginFirst: "Сначала войдите", buyer_: "Покупатель", qty: "Кол-во", currency: "сомони",
    resubmitted: "Товар отправлен на повторную модерацию", language: "Язык", needsLogin: "Войдите, чтобы купить",
    allStatuses: "Все статусы", move: "Перевести в…", noItems: "Пусто", sellerNote: "Комментарий модератора",
    s_PLACED: "Принят", s_CONFIRMED: "Подтверждён", s_PROCESSING: "Готовится", s_SHIPPED: "Отправлен",
    s_DELIVERED: "Доставлен", s_CANCELLED: "Отменён", s_PENDING: "На модерации", s_APPROVED: "Одобрен",
    s_REJECTED: "Отклонён", s_ARCHIVED: "В архиве",
    err_INVALID_CREDENTIALS: "Неверная почта или пароль", err_EMAIL_OR_PHONE_ALREADY_EXISTS: "Эта почта или телефон уже зарегистрированы",
    err_TOO_MANY_ATTEMPTS: "Слишком много попыток. Попробуйте позже", err_INSUFFICIENT_STOCK: "Недостаточно товара на складе",
    err_PRODUCT_UNAVAILABLE: "Товар недоступен", err_CANNOT_BUY_OWN_PRODUCT: "Нельзя покупать собственный товар",
    err_VALIDATION_ERROR: "Данные заполнены неверно", err_FORBIDDEN: "Нет доступа", err_NOT_FOUND: "Не найдено",
    err_INVALID_STATUS_TRANSITION: "Такой переход статуса невозможен", err_INVALID_STATE: "Действие невозможно в текущем состоянии",
    err_CANNOT_MODIFY_SELF: "Нельзя менять собственный аккаунт", err_INVALID_OR_EXPIRED_TOKEN: "Сессия истекла. Войдите снова",
    courier: "Курьер", courierRole: "Курьер", deliveries: "Мои доставки", assignCourier: "Назначить курьера", noCourier: "Курьер не назначен",
    markShipped: "Забрал, везу", markDelivered: "Доставлено", buyerName: "Покупатель", waitingManager: "Ждёт подготовки менеджером",
    err_COURIER_REQUIRED: "Сначала назначьте курьера", err_COURIER_UNAVAILABLE: "Этот курьер недоступен",
    err_network: "Сервер не отвечает"
  }
};
const NEXT = { PLACED: ["CONFIRMED", "CANCELLED"], CONFIRMED: ["PROCESSING", "CANCELLED"], PROCESSING: ["SHIPPED", "CANCELLED"], SHIPPED: ["DELIVERED"], DELIVERED: [], CANCELLED: [] };

// ---------- state ----------
const store = {
  get(k) { try { return sessionStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { v == null ? sessionStorage.removeItem(k) : sessionStorage.setItem(k, v); } catch { /* storage unavailable */ } }
};
const lstore = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } }
};
const state = {
  lang: lstore.get("usto_lang") === "ru" ? "ru" : "tg",
  token: store.get("usto_token"), user: null, view: "catalog",
  cart: safeJson(store.get("usto_cart"), [])
};
function safeJson(s, d) { try { const v = JSON.parse(s); return Array.isArray(v) ? v : d; } catch { return d; } }
const t = k => (T[state.lang][k] ?? k);

// ---------- helpers ----------
function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "value") el.value = v;
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return el;
}
const money = v => `${Number(v).toFixed(2)} ${t("currency")}`;
const title = p => (state.lang === "ru" ? p.titleRu : p.titleTg);
const desc = p => (state.lang === "ru" ? p.descriptionRu : p.descriptionTg) || "";
const badge = s => h("span", { class: `badge ${s}` }, t(`s_${s}`));
const fmtDate = d => new Date(d).toLocaleString(state.lang === "ru" ? "ru-RU" : "tg-TJ", { dateStyle: "short", timeStyle: "short" });

let toastTimer;
function toast(msg, isErr) {
  const el = document.getElementById("toast");
  el.textContent = msg; el.className = `show${isErr ? " err" : ""}`;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.className = ""; }, 3500);
}

async function api(path, { method = "GET", body } = {}) {
  let res;
  try {
    res = await fetch(`/api${path}`, {
      method, headers: { ...(body ? { "Content-Type": "application/json" } : {}), ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}) },
      body: body ? JSON.stringify(body) : undefined
    });
  } catch { throw Object.assign(new Error("network"), { code: "network" }); }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && state.token && data.error === "INVALID_OR_EXPIRED_TOKEN") setSession(null, null);
    throw Object.assign(new Error(data.error || "ERROR"), { code: data.error || "ERROR", data });
  }
  return data;
}
const errText = e => t(`err_${e.code}`) !== `err_${e.code}` ? t(`err_${e.code}`) : (e.data?.details?.[0]?.message || e.code || "Error");
const run = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(errText(e), true); if (e.code === "INVALID_OR_EXPIRED_TOKEN") go("login"); } };

function setSession(token, user) {
  state.token = token; state.user = user; store.set("usto_token", token);
  if (!token) { state.cart = []; saveCart(); }
}
const saveCart = () => store.set("usto_cart", JSON.stringify(state.cart));
const isRole = (...r) => state.user && r.includes(state.user.role);

function go(view) { state.view = view; render(); window.scrollTo(0, 0); }

// ---------- layout ----------
function renderNav() {
  const link = (view, label) => h("button", { class: `link${state.view === view ? " active" : ""}`, onclick: () => go(view) }, label);
  const items = [link("catalog", t("catalog")), link("cart", `${t("cart")}${state.cart.length ? ` (${state.cart.reduce((n, i) => n + i.qty, 0)})` : ""}`)];
  if (state.user) items.push(link("orders", t("orders")));
  if (isRole("COURIER")) items.push(link("courier", t("deliveries")));
  if (isRole("SELLER", "ADMIN")) items.push(link("seller", t("seller")));
  if (isRole("MANAGER", "ADMIN")) items.push(link("moderation", t("moderation")));
  if (isRole("ADMIN")) items.push(link("admin", t("admin")));
  const right = state.user
    ? [link("account", state.user.name), h("button", { onclick: () => { setSession(null, null); go("catalog"); } }, t("logout"))]
    : [link("login", t("login")), h("button", { class: "primary", onclick: () => go("register") }, t("register"))];
  const langSel = h("select", { "aria-label": t("language"), style: "width:auto", onchange: e => { state.lang = e.target.value; lstore.set("usto_lang", state.lang); document.documentElement.lang = state.lang; render(); } },
    h("option", { value: "tg", selected: state.lang === "tg" }, "Тоҷикӣ"), h("option", { value: "ru", selected: state.lang === "ru" }, "Русский"));
  document.getElementById("nav").replaceChildren(h("span", { class: "logo", onclick: () => go("catalog") }, "USTO"), h("nav", {}, items), ...right, langSel);
}

function render() {
  renderNav();
  const main = document.getElementById("main");
  const needLogin = ["orders", "seller", "moderation", "admin", "account", "courier"].includes(state.view) && !state.user;
  const view = needLogin ? "login" : state.view;
  const views = { catalog: viewCatalog, cart: viewCart, login: viewLogin, register: viewRegister, orders: viewOrders, seller: viewSeller, moderation: viewModeration, admin: viewAdmin, account: viewAccount, courier: viewCourier };
  const root = h("div");
  main.replaceChildren(root);
  Promise.resolve(views[view](root)).catch(e => toast(errText(e), true));
}

const field = (label, input) => h("div", {}, h("label", {}, label), input);
const inp = (name, type = "text", extra = {}) => h("input", { name, type, ...extra });
const formData = form => Object.fromEntries(new FormData(form).entries());

// ---------- catalog ----------
async function viewCatalog(root) {
  const q = h("input", { type: "search", placeholder: t("search"), class: "grow", "aria-label": t("search") });
  const city = h("input", { placeholder: t("city"), style: "width:160px", "aria-label": t("city") });
  const list = h("div", { class: "grid" });
  const load = run(async () => {
    const params = new URLSearchParams({ limit: "60" });
    if (q.value.trim()) params.set("q", q.value.trim());
    if (city.value.trim()) params.set("city", city.value.trim());
    const { products } = await api(`/products?${params}`);
    list.replaceChildren(...(products.length ? products.map(productCard) : [h("div", { class: "empty" }, t("noProducts"))]));
  });
  q.addEventListener("keydown", e => { if (e.key === "Enter") load(); });
  city.addEventListener("keydown", e => { if (e.key === "Enter") load(); });
  root.append(h("h1", {}, t("catalog")), h("div", { class: "row" }, q, city, h("button", { class: "primary", onclick: load }, t("find"))), h("p"), list);
  await load();
}

function productCard(p) {
  const img = h("div", { class: "img" }, p.imageUrl ? h("img", { src: p.imageUrl, alt: "", loading: "lazy", referrerpolicy: "no-referrer" }) : "🛍");
  const out = p.stock < 1;
  return h("div", { class: "card product" }, img, h("h3", {}, title(p)),
    h("div", { class: "muted" }, `${p.city} · ${p.category}`),
    desc(p) ? h("div", { class: "muted" }, desc(p).slice(0, 90)) : null,
    h("div", { class: "row" }, h("span", { class: "price" }, money(p.priceTjs)), h("span", { class: "muted" }, out ? t("outOfStock") : `${p.stock} ${t("inStock")}`)),
    h("button", { class: "primary", disabled: out, onclick: () => addToCart(p) }, t("addToCart")));
}

function addToCart(p) {
  if (!state.user) { toast(t("needsLogin"), true); return go("login"); }
  const line = state.cart.find(i => i.product.id === p.id);
  if (line) line.qty = Math.min(line.qty + 1, p.stock, 100); else state.cart.push({ product: p, qty: 1 });
  saveCart(); renderNav(); toast(`✓ ${title(p)}`);
}

// ---------- cart & checkout ----------
function viewCart(root) {
  root.append(h("h1", {}, t("cart")));
  if (!state.cart.length) return root.append(h("div", { class: "empty" }, t("cartEmpty")));
  const total = () => state.cart.reduce((s, i) => s + Number(i.product.priceTjs) * i.qty, 0);
  const totalEl = h("b", {}, money(total()));
  const lines = state.cart.map(i => {
    const qty = h("input", { type: "number", min: 1, max: Math.min(i.product.stock, 100), value: i.qty, style: "width:80px", "aria-label": t("qty"),
      onchange: e => { i.qty = Math.max(1, Math.min(Number(e.target.value) || 1, i.product.stock, 100)); e.target.value = i.qty; saveCart(); totalEl.textContent = money(total()); renderNav(); } });
    return h("div", { class: "card row" }, h("span", { class: "grow" }, title(i.product), h("div", { class: "muted" }, money(i.product.priceTjs))), qty,
      h("button", { class: "danger", onclick: () => { state.cart = state.cart.filter(x => x !== i); saveCart(); render(); } }, t("remove")));
  });
  const form = h("form", { class: "card form", onsubmit: run(async e => {
    e.preventDefault();
    const d = formData(e.target);
    const body = { city: d.city, address: d.address, phone: d.phone, note: d.note || undefined, items: state.cart.map(i => ({ productId: i.product.id, quantity: i.qty })) };
    await api("/orders", { method: "POST", body });
    state.cart = []; saveCart(); toast(t("orderPlaced")); go("orders");
  }) },
    h("h2", {}, t("checkout")), field(t("city"), inp("city", "text", { required: true, minlength: 2, value: state.user?.city || "" })),
    field(t("address"), inp("address", "text", { required: true, minlength: 5 })),
    field(t("phone"), inp("phone", "tel", { required: true, value: state.user?.phone || "", placeholder: "+992 900 000 000" })),
    field(t("note"), h("textarea", { name: "note", rows: 2, maxlength: 1000 })),
    h("p", {}, `${t("total")}: `, totalEl), h("button", { class: "primary", type: "submit" }, t("placeOrder")));
  root.append(h("div", { class: "list" }, lines), form);
}

// ---------- auth ----------
function viewLogin(root) {
  root.append(h("h1", {}, t("login")), h("form", { class: "card form", onsubmit: run(async e => {
    e.preventDefault();
    const { token, user } = await api("/auth/login", { method: "POST", body: formData(e.target) });
    setSession(token, user); go(user.role === "MANAGER" ? "moderation" : user.role === "ADMIN" ? "admin" : user.role === "COURIER" ? "courier" : "catalog");
  }) }, field(t("email"), inp("email", "email", { required: true, autocomplete: "username" })),
    field(t("password"), inp("password", "password", { required: true, autocomplete: "current-password" })),
    h("p"), h("button", { class: "primary", type: "submit" }, t("login")),
    h("p", { class: "muted" }, h("button", { class: "link", type: "button", onclick: () => go("register") }, t("register")))));
}

function viewRegister(root) {
  const role = h("select", { name: "role" }, h("option", { value: "BUYER" }, t("buyer")), h("option", { value: "SELLER" }, t("sellerRole")));
  root.append(h("h1", {}, t("register")), h("form", { class: "card form", onsubmit: run(async e => {
    e.preventDefault();
    const d = formData(e.target); if (!d.phone) delete d.phone;
    const { token, user } = await api("/auth/register", { method: "POST", body: d });
    setSession(token, user); go(user.role === "SELLER" ? "seller" : "catalog");
  }) }, field(t("name"), inp("name", "text", { required: true, minlength: 2, maxlength: 80, autocomplete: "name" })),
    field(t("email"), inp("email", "email", { required: true, autocomplete: "username" })),
    field(t("phone"), inp("phone", "tel", { placeholder: "+992 900 000 000", autocomplete: "tel" })),
    field(`${t("password")} (${t("pwHint")})`, inp("password", "password", { required: true, minlength: 10, autocomplete: "new-password" })),
    field(t("role"), role), h("p"), h("button", { class: "primary", type: "submit" }, t("register"))));
}

async function viewAccount(root) {
  const { user } = await api("/auth/me"); state.user = user;
  const profile = h("form", { class: "card form", onsubmit: run(async e => {
    e.preventDefault(); const d = formData(e.target); if (!d.phone) delete d.phone;
    state.user = (await api("/auth/me", { method: "PATCH", body: d })).user; toast(t("saved")); renderNav();
  }) }, h("h2", {}, t("account")), field(t("name"), inp("name", "text", { value: user.name, required: true, minlength: 2 })),
    field(t("phone"), inp("phone", "tel", { value: user.phone || "" })), h("p", { class: "muted" }, `${user.email} · ${t(user.role === "BUYER" ? "buyer" : user.role === "SELLER" ? "sellerRole" : user.role === "MANAGER" ? "manager" : user.role === "COURIER" ? "courierRole" : "adminRole")}`),
    h("button", { class: "primary", type: "submit" }, t("save")));
  const pw = h("form", { class: "card form", onsubmit: run(async e => {
    e.preventDefault(); const d = formData(e.target);
    const r = await api("/auth/change-password", { method: "POST", body: d });
    setSession(r.token, r.user); e.target.reset(); toast(t("saved"));
  }) }, h("h2", {}, t("changePw")), field(t("currentPw"), inp("currentPassword", "password", { required: true, autocomplete: "current-password" })),
    field(`${t("newPw")} (${t("pwHint")})`, inp("newPassword", "password", { required: true, minlength: 10, autocomplete: "new-password" })),
    h("p"), h("button", { type: "submit" }, t("save")));
  root.append(h("h1", {}, t("account")), h("div", { class: "list" }, profile, pw,
    h("div", {}, h("button", { class: "danger", onclick: run(async () => { await api("/auth/logout-all", { method: "POST" }); setSession(null, null); go("login"); }) }, t("logoutAll")))));
}

// ---------- buyer orders ----------
const orderCard = (o, extra) => h("div", { class: "card" },
  h("div", { class: "row" }, h("b", { class: "grow" }, `#${o.id.slice(-6)}`), badge(o.status), h("span", { class: "muted" }, fmtDate(o.createdAt))),
  h("div", {}, o.items.map(i => h("div", {}, `${state.lang === "ru" ? i.productTitleRu : i.productTitleTg} × ${i.quantity} — ${money(Number(i.unitPriceTjs) * i.quantity)}`))),
  h("div", { class: "muted" }, `${o.city}, ${o.address} · ${o.phone}`),
  h("div", { class: "row" }, h("b", { class: "grow" }, `${t("total")}: ${money(o.totalTjs)}`), extra));

async function viewOrders(root) {
  const { orders } = await api("/orders/mine");
  root.append(h("h1", {}, t("orders")), orders.length ? h("div", { class: "list" }, orders.map(o => orderCard(o,
    o.status === "PLACED" ? h("button", { class: "danger", onclick: run(async () => { await api(`/orders/${o.id}/cancel`, { method: "POST" }); render(); }) }, t("cancel")) : null)))
    : h("div", { class: "empty" }, t("noOrders")));
}

// ---------- seller ----------
async function viewSeller(root) {
  const [{ products }, { items }] = await Promise.all([api("/seller/products"), api("/seller/orders")]);
  const form = h("form", { class: "card form", onsubmit: run(async e => {
    e.preventDefault(); const d = formData(e.target);
    for (const k of ["descriptionTg", "descriptionRu", "imageUrl"]) if (!d[k]) delete d[k];
    await api("/products", { method: "POST", body: d }); toast(t("saved")); render();
  }) }, h("h2", {}, t("newProduct")),
    field(t("titleTg"), inp("titleTg", "text", { required: true, minlength: 2 })), field(t("titleRu"), inp("titleRu", "text", { required: true, minlength: 2 })),
    field(t("category"), inp("category", "text", { required: true, minlength: 2 })), field(t("city"), inp("city", "text", { required: true, minlength: 2 })),
    h("div", { class: "row" }, h("div", { class: "grow" }, field(t("price"), inp("priceTjs", "number", { required: true, min: "0.01", step: "0.01" }))),
      h("div", { class: "grow" }, field(t("stock"), inp("stock", "number", { required: true, min: "0", step: "1", value: "1" })))),
    field(t("descTg"), h("textarea", { name: "descriptionTg", rows: 2 })), field(t("descRu"), h("textarea", { name: "descriptionRu", rows: 2 })),
    field(t("imageUrl"), inp("imageUrl", "url", { pattern: "https://.*" })), h("p"), h("button", { class: "primary", type: "submit" }, t("create")));

  const mine = products.map(p => {
    const price = h("input", { type: "number", step: "0.01", min: "0.01", value: Number(p.priceTjs), style: "width:110px", "aria-label": t("price") });
    const stock = h("input", { type: "number", step: "1", min: "0", value: p.stock, style: "width:90px", "aria-label": t("stock") });
    const archived = p.status === "ARCHIVED";
    return h("div", { class: "card" }, h("div", { class: "row" }, h("b", { class: "grow" }, title(p)), badge(p.status)),
      p.reviewNote ? h("div", { class: "muted" }, `${t("sellerNote")}: ${p.reviewNote}`) : null,
      archived ? null : h("div", { class: "row" }, price, stock,
        h("button", { onclick: run(async () => { await api(`/products/${p.id}`, { method: "PATCH", body: { priceTjs: Number(price.value), stock: Number(stock.value) } }); toast(t("saved")); render(); }) }, t("save")),
        h("button", { class: "danger", onclick: run(async () => { await api(`/products/${p.id}`, { method: "DELETE" }); render(); }) }, t("archive"))));
  });
  const sales = items.length ? h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["", t("qty"), t("price"), t("status"), t("city")].map(x => h("th", {}, x)))),
    h("tbody", {}, items.map(i => h("tr", {}, h("td", {}, state.lang === "ru" ? i.productTitleRu : i.productTitleTg), h("td", {}, i.quantity), h("td", {}, money(i.unitPriceTjs)), h("td", {}, badge(i.order.status)), h("td", {}, i.order.city))))))
    : h("div", { class: "empty" }, t("noItems"));
  root.append(h("h1", {}, t("seller")), form, h("h2", {}, t("myProducts")), mine.length ? h("div", { class: "list" }, mine) : h("div", { class: "empty" }, t("noItems")), h("h2", {}, t("sales")), sales);
}

// ---------- courier ----------
async function viewCourier(root) {
  const { orders } = await api("/courier/orders");
  const action = o => {
    const to = o.status === "PROCESSING" ? "SHIPPED" : o.status === "SHIPPED" ? "DELIVERED" : null;
    if (!to) return o.status === "CONFIRMED" ? h("span", { class: "muted" }, t("waitingManager")) : null;
    return h("button", { class: "primary", onclick: run(async () => { await api(`/courier/orders/${o.id}/status`, { method: "PATCH", body: { status: to } }); render(); }) }, t(to === "SHIPPED" ? "markShipped" : "markDelivered"));
  };
  root.append(h("h1", {}, t("deliveries")), orders.length
    ? h("div", { class: "list" }, orders.map(o => orderCard(o, action(o))))
    : h("div", { class: "empty" }, t("noOrders")));
}

// ---------- moderation (manager/admin) ----------
async function viewModeration(root) {
  const [{ products }, { orders }, { couriers }] = await Promise.all([api("/manager/products/pending"), api("/manager/orders"), api("/manager/couriers")]);
  const pending = products.map(p => {
    const note = h("input", { placeholder: t("reviewNote"), class: "grow", maxlength: 500 });
    const decide = d => run(async () => { await api(`/products/${p.id}/review`, { method: "PATCH", body: { decision: d, note: note.value.trim() || undefined } }); render(); });
    return h("div", { class: "card" }, h("div", { class: "row" }, h("b", { class: "grow" }, `${title(p)} — ${money(p.priceTjs)}`), h("span", { class: "muted" }, p.seller?.name)),
      h("div", { class: "muted" }, `${p.city} · ${p.category} · ${p.stock}`), desc(p) ? h("div", {}, desc(p)) : null,
      p.imageUrl ? h("div", { class: "muted" }, p.imageUrl) : null,
      h("div", { class: "row" }, note, h("button", { class: "primary", onclick: decide("APPROVED") }, t("approve")), h("button", { class: "danger", onclick: decide("REJECTED") }, t("reject"))));
  });
  const ord = orders.map(o => {
    const next = NEXT[o.status] || [];
    const sel = h("select", { style: "width:auto", "aria-label": t("move"), onchange: run(async e => { if (!e.target.value) return; await api(`/manager/orders/${o.id}/status`, { method: "PATCH", body: { status: e.target.value } }); render(); }) },
      h("option", { value: "" }, t("move")), next.map(s => h("option", { value: s }, t(`s_${s}`))));
    const canAssign = ["PLACED", "CONFIRMED", "PROCESSING"].includes(o.status);
    const courierEl = canAssign
      ? h("select", { style: "width:auto", "aria-label": t("assignCourier"), onchange: run(async e => { await api(`/manager/orders/${o.id}/courier`, { method: "PATCH", body: { courierId: e.target.value || null } }); toast(t("saved")); }) },
          h("option", { value: "" }, t("noCourier")), couriers.map(c => h("option", { value: c.id, selected: o.courier?.id === c.id }, c.name)))
      : h("span", { class: "muted" }, o.courier ? `${t("courier")}: ${o.courier.name}` : "");
    return orderCard(o, h("div", { class: "row" }, h("span", { class: "muted" }, `${o.buyer?.name || ""} ${o.buyer?.email || ""}`), courierEl, next.length ? sel : null));
  });
  root.append(h("h1", {}, t("moderation")), h("h2", {}, `${t("pending")} (${products.length})`), pending.length ? h("div", { class: "list" }, pending) : h("div", { class: "empty" }, t("noItems")),
    h("h2", {}, t("orders")), ord.length ? h("div", { class: "list" }, ord) : h("div", { class: "empty" }, t("noOrders")));
}

// ---------- admin ----------
async function viewAdmin(root) {
  const [ov, { users }] = await Promise.all([api("/admin/overview"), api("/admin/users?limit=100")]);
  const stats = h("div", { class: "stat" }, [[t("usersN"), ov.users], [t("productsN"), ov.products], [t("approvedN"), ov.approvedProducts], [t("pendingN"), ov.pendingProducts], [t("ordersN"), ov.orders]]
    .map(([l, n]) => h("div", { class: "card" }, h("b", {}, n), h("span", { class: "muted" }, l))));
  const roles = [["BUYER", "buyer"], ["SELLER", "sellerRole"], ["MANAGER", "manager"], ["COURIER", "courierRole"], ["ADMIN", "adminRole"]];
  const roleOptions = sel => roles.map(([v, k]) => h("option", { value: v, selected: v === sel }, t(k)));
  const rows = users.map(u => {
    const self = u.id === state.user.id;
    const roleSel = h("select", { disabled: self, style: "width:auto", "aria-label": t("role"), onchange: run(async e => { await api(`/admin/users/${u.id}`, { method: "PATCH", body: { role: e.target.value } }); toast(t("saved")); }) }, roleOptions(u.role));
    const act = h("input", { type: "checkbox", checked: u.active, disabled: self, style: "width:auto", "aria-label": t("active"), onchange: run(async e => { await api(`/admin/users/${u.id}`, { method: "PATCH", body: { active: e.target.checked } }); toast(t("saved")); }) });
    return h("tr", {}, h("td", {}, u.name), h("td", {}, u.email), h("td", {}, roleSel), h("td", {}, act));
  });
  const form = h("form", { class: "card form", onsubmit: run(async e => {
    e.preventDefault(); const d = formData(e.target); if (!d.phone) delete d.phone;
    await api("/admin/users", { method: "POST", body: d }); toast(t("saved")); render();
  }) }, h("h2", {}, t("newUser")), field(t("name"), inp("name", "text", { required: true, minlength: 2 })), field(t("email"), inp("email", "email", { required: true })),
    field(t("phone"), inp("phone", "tel")), field(`${t("password")} (${t("pwHint")})`, inp("password", "password", { required: true, minlength: 10, autocomplete: "new-password" })),
    field(t("role"), h("select", { name: "role" }, roleOptions("MANAGER"))), h("p"), h("button", { class: "primary", type: "submit" }, t("create")));
  root.append(h("h1", {}, t("overview")), stats, h("h2", {}, t("users")),
    h("div", { class: "tablewrap card" }, h("table", {}, h("thead", {}, h("tr", {}, [t("name"), t("email"), t("role"), t("active")].map(x => h("th", {}, x)))), h("tbody", {}, rows))), h("p"), form);
}

// ---------- boot ----------
(async function boot() {
  document.documentElement.lang = state.lang;
  if (state.token) {
    try { state.user = (await api("/auth/me")).user; } catch { setSession(null, null); }
  }
  render();
})();
