import test from "node:test";
import assert from "node:assert/strict";
import {
  COURIER_TARGETS, requiresCourier, ROLES, canTransitionOrder, mergeItems, normalizePhone, passwordFitsBcrypt, canReviewProduct, restocksOnCancel
} from "../src/rules.js";

test("order transitions: allowed and forbidden", () => {
  assert.equal(canTransitionOrder("PLACED", "CONFIRMED"), true);
  assert.equal(canTransitionOrder("PROCESSING", "CANCELLED"), true);
  assert.equal(canTransitionOrder("CANCELLED", "DELIVERED"), false);
  assert.equal(canTransitionOrder("DELIVERED", "CANCELLED"), false);
  assert.equal(canTransitionOrder("SHIPPED", "CANCELLED"), false);
  assert.equal(canTransitionOrder("PLACED", "DELIVERED"), false);
});

test("only cancel restocks", () => {
  assert.equal(restocksOnCancel("CANCELLED"), true);
  assert.equal(restocksOnCancel("DELIVERED"), false);
});

test("only pending products can be reviewed", () => {
  assert.equal(canReviewProduct("PENDING"), true);
  for (const s of ["APPROVED", "REJECTED", "ARCHIVED"]) assert.equal(canReviewProduct(s), false);
});

test("mergeItems sums duplicates and sorts by id (duplicate-line stock bypass)", () => {
  const merged = mergeItems([
    { productId: "b", quantity: 5 },
    { productId: "a", quantity: 1 },
    { productId: "b", quantity: 5 }
  ]);
  assert.deepEqual(merged, [{ productId: "a", quantity: 1 }, { productId: "b", quantity: 10 }]);
});

test("normalizePhone", () => {
  assert.equal(normalizePhone("900 000 000"), "+992900000000");
  assert.equal(normalizePhone("992900000000"), "+992900000000");
  assert.equal(normalizePhone("+992 (900) 000-000"), "+992900000000");
  assert.equal(normalizePhone("00992900000000"), "+992900000000");
  assert.equal(normalizePhone("+79161234567"), "+79161234567");
  assert.equal(normalizePhone("abc"), null);
  assert.equal(normalizePhone("123"), null);
});

test("password byte limit counts bytes, not characters", () => {
  assert.equal(passwordFitsBcrypt("a".repeat(72)), true);
  assert.equal(passwordFitsBcrypt("a".repeat(73)), false);
  assert.equal(passwordFitsBcrypt("ӯ".repeat(36)), true);  // 36 chars = 72 bytes
  assert.equal(passwordFitsBcrypt("ӯ".repeat(37)), false); // 37 chars = 74 bytes
});

test("courier rules", () => {
  assert.deepEqual(COURIER_TARGETS, ["SHIPPED", "DELIVERED"]);
  assert.equal(requiresCourier("SHIPPED"), true);
  assert.equal(requiresCourier("CONFIRMED"), false);
  assert.ok(ROLES.includes("COURIER"));
  // couriers cannot cancel or confirm
  assert.equal(COURIER_TARGETS.includes("CANCELLED"), false);
});
